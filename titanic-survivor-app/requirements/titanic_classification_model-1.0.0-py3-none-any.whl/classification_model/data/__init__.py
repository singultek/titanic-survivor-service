TITANIC_DATA = 'https://www.openml.org/data/get_csv/16826755/phpMYEkMl'
